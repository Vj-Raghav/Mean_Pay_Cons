import { Component } from '@angular/core';
import {GlarusService} from './glarus.service'
import { FormBuilder, Validators, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  dataArray=[];
  categories=[];
  visibleArray=[];
  selected;
  firstQues;
  categoryValue="";
  categoryForm : FormGroup;
  constructor(private formbuilder: FormBuilder,private glarusService:GlarusService){}
  ngOnInit(){
    this.dataArray=[]
    this.categories = this.glarusService.getCategory()
    // this.glarusService.getques(this.categoryValue).subscribe(sdata =>
    //   sdata.map(item=>this.dataArray.push(item)))
    this.categoryForm = this.formbuilder.group({
      yes:[''],
      no:[''],
      empty:['']
    })
  }
  fetchDetails(event){
    this.selected=true;
    this.dataArray=[]
    this.visibleArray=[]
    this.firstQues=""
    this.categoryValue = event.value
    this.glarusService.getques(this.categoryValue).subscribe(sdata =>{
      sdata.map(item=>this.dataArray.push(item))
      if(this.dataArray.length>0){
        this.firstQues =this.dataArray[0].choices.questionName
      }
      for(let i=1;i<this.dataArray.length;i++){
        this.visibleArray[i-1] =this.dataArray[i]
      }
    })
  }
  changeFirstQues(event){
    this.firstQues = event.value
  }
}
