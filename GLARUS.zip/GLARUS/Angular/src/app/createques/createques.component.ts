import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import {GlarusService} from '../glarus.service'
import {MatSnackBar} from '@angular/material/snack-bar';

@Component({
  selector: 'app-createques',
  templateUrl: './createques.component.html',
  styleUrls: ['./createques.component.css']
})
export class CreatequesComponent implements OnInit {
  categories =[]
  questions=["yes or No","checkbox","radio"]
  yn=true;
  rad=true;
  cb=true;
  questionaireForm : FormGroup;
  constructor(private _snackBar: MatSnackBar,private formbuilder: FormBuilder,private glarusService:GlarusService) { }

  ngOnInit(): void {
    this.categories = this.glarusService.getCategory()
    this.questionaireForm = this.formbuilder.group({
      questionName:[''],
      questionType:[''],
      category:['',Validators.required],
      choices: this.formbuilder.group({
        choice1:[''],
        choice2:[''],
        choice3:[null],
        choice4:[null]
      }),
    })

  }
  onSave(){
    this.glarusService.saveQues(this.questionaireForm.value)
    this.questionaireForm.controls['questionName'].reset()
    this.questionaireForm.controls['questionType'].reset()
    this.questionaireForm.controls['choices'].reset()
    this._snackBar.open("Successfully Saved", "dismiss", {
      duration: 3000,
    });
  }
  displaySelected(event){
    this.yn=this.rad=this.cb=true;
    if(event.value==="yes or No"){
      this.yn=false
    }else if(event.value==="checkbox"){
      this.cb=false
    }else if(event.value==="radio"){
      this.rad=false
    }
  }

}
