import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreatequesComponent } from './createques.component';

describe('CreatequesComponent', () => {
  let component: CreatequesComponent;
  let fixture: ComponentFixture<CreatequesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreatequesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreatequesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
