import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {choiceArray} from './choice'
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GlarusService {

  constructor(private http:HttpClient) { }
  getCategory(){
    return ["dentist","ortho","neuro","physio","gynaco","gastro"]
  }
  saveQues(data:any){
    this.http.post("http://localhost:3500/saveCat",data).subscribe(()=>{
      console.log("hi")
    })}
  getques(category):Observable<choiceArray[]>{
     return this.http.get<choiceArray[]>("http://localhost:3500/ques/"+category)
}}
