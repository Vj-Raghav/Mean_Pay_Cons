import { TestBed } from '@angular/core/testing';

import { GlarusService } from './glarus.service';

describe('GlarusService', () => {
  let service: GlarusService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GlarusService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
