const express = require('express');
const blogHandler = require('../Handler/BlogHandler')
const router = express.Router();

router.post('/saveCat', blogHandler.saveQues)
router.get('/ques/:category', blogHandler.ques)

module.exports = router;