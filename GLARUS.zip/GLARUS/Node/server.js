const mongoose = require('mongoose')
const app = require('./app')

mongoose.connect('mongodb+srv://Vijay:hqjh3WjLbeR0I9xB@cluster0.hjhk3.mongodb.net/Bank?retryWrites=true&w=majority',
  {
    useNewUrlParser: true,
    useFindAndModify: false,
    useCreateIndex: true,
    useUnifiedTopology: true
  }).then(
    console.log('connection successful')
  ) //Connecting to the database

const port = 3500;

app.listen(port, () => {
  console.log('Listening at 3500');
});
