const Glarus = require('../DB/schema')

exports.saveQues = async (req, res, next) => {
    try {
        if (req.body.choices.choice3 != null) {
            var choice = {
                questionName: req.body.questionName,
                questionType: req.body.questionType,
                choice1: req.body.choices.choice1,
                choice2: req.body.choices.choice2,
                choice3: req.body.choices.choice3,
                choice4: req.body.choices.choice4
            }
        } else {
            var choice = {
                questionName: req.body.questionName,
                questionType: req.body.questionType,
                choice1: req.body.choices.choice1,
                choice2: req.body.choices.choice2
            }
        }
        const cat = await Glarus.updateOne
            ({ category: req.body.category }, { $push: { choices: choice } },
                { upsert: true, new: true, setDefaultsOnInsert: true })
        if (cat) {
            res.status(200).json({ "message": "success" })
        } else {
            let err = new Error("Some error Occured")
            err.statusCode = 502
            throw err
        }

    } catch (err) {
        next(err)
    }
}

exports.ques = async (req, res, next) => {
    try {
        const ques = await Glarus.aggregate([{ $match: { category: req.params.category } },
        { $project: { choices: 1, _id: 0 } },
        { $unwind: "$choices" }
        ])
        if (ques) {
            res.status(200).json(ques)
        } else {
            let err = new Error("Some error Occured")
            err.statusCode = 502
            throw err
        }
    } catch (err) {
        next(err)
    }
}