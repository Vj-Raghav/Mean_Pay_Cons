//MongoDB Schema
const mongoose = require('mongoose');

const glarusSchema = new mongoose.Schema({
    category: {
        type: String,
        required: true
    },
    choices: [{
        questionName: {type: String,required: true},
        questionType: {type: String,required: true},
        choice1: { type: String, required: true },
        choice2: { type: String, required: true },
        choice3: { type: String },
        choice4: { type: String }
    }]
})

module.exports = mongoose.model("Glarus", glarusSchema);
